from django.contrib import admin
from django.utils.safestring import mark_safe

from .models import Category, Item


class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ['name']



class ItemAdmin(admin.ModelAdmin):
    list_display = ('name', 'image_show', 'category', 'price',)
    search_fields = ['name', 'category__name', 'price']

    def image_show(self, obj):
        if obj.image:
            return mark_safe("<img src ='{}' width='100' />".format(obj.image.url))
        return "None"

    image_show.__name__ = "Картинка"

admin.site.register(Category, CategoryAdmin)
admin.site.register(Item, ItemAdmin)