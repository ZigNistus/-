from django.db import models

# Create your models here.


class Category(models.Model):
    name = models.CharField(max_length=20, verbose_name="Категория")

    def __str__(self):
        return self.name


    class Meta:
        verbose_name = 'Категория'
        verbose_name_plural = 'Категории'

class Item(models.Model):
    name = models.CharField(max_length=50, verbose_name="Товар")
    desc = models.TextField(verbose_name="Описание")
    image = models.ImageField(upload_to="item/%Y/%m/%d", blank=True, verbose_name="Картинка")
    category = models.ForeignKey(Category, on_delete=models.CASCADE, verbose_name="Категория")
    price = models.CharField(max_length=10, verbose_name="Цена")

    def __str__(self):
        return f'{self.name} {self.category}'

    class Meta:
        verbose_name = 'Товар'
        verbose_name_plural = 'Товары'