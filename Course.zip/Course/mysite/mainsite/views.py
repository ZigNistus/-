from django.http import HttpResponse

from django.shortcuts import render
from django.template import RequestContext
from .models import Category, Item
from cart.forms import CartAddProductForm

def index(request):
    nodles = Item.objects.filter(category__name='Лапша/Рис')
    rolls = Item.objects.filter(category__name='Роллы')
    deserts = Item.objects.filter(category__name='Десерты')
    after = Item.objects.filter(category__name='Закуски')
    drinks = Item.objects.filter(category__name='Напитки')
    cart_product_form = CartAddProductForm()
    context = {'nodles': nodles,
               'sushi': rolls,
               'deserts': deserts,
               'rolls': after,
               'drinks': drinks,
               'cart_product_form': cart_product_form}
    return render(request, 'shop/main.html', context)